var pdfObject;

function loadIFrameView(url){
    try{
    	
    	
    	/* 
    	 * Reason I do 'object' for IE is, it can handle multiple pdfs as objects and by creating it
    	 * as an object
    	 *
    	 */
    	if (navigator.appName.indexOf ("Microsoft") !=-1) //For IE (7)
    	{
    	//document.getElementById("pdfFrame").innerHTML = "<object id='pdfIFrame' data='"+url+"' type='application/pdf'>  </object>";	
    	}
    	else //for non IE browser (FF, Safari)
    	{
    	//	document.getElementById("pdfFrame").innerHTML = "<iframe id='pdfIFrame' name='pdfIFrame' src='"+url+"' frameborder='0'>  </iframe>";	
    	}

    	mywindow = window.open(url, "mywindow",width=1500,height=1000);
    	
        //mywindow.moveTo(0, 0);

    //	pdfObject = document.getElementById("pdfIFrame");
    }
    catch(e)
     {
    	alert("Error in loadIFrame \name:"+e.name+"\nmessage:"+e.message);
      }
}
function loadIFrameSample(){
    try{
    	
    	
    	/* 
    	 * Reason I do 'object' for IE is, it can handle multiple pdfs as objects and by creating it
    	 * as an object
    	 *
    	 */
    	if (navigator.appName.indexOf ("Microsoft") !=-1) //For IE (7)
    	{
    	//document.getElementById("pdfFrame").innerHTML = "<object id='pdfIFrame' data='"+url+"' type='application/pdf'>  </object>";	
    	}
    	else //for non IE browser (FF, Safari)
    	{
    	//	document.getElementById("pdfFrame").innerHTML = "<iframe id='pdfIFrame' name='pdfIFrame' src='"+url+"' frameborder='0'>  </iframe>";	
    	}

    	
    	var myWindow = window.open("", "myWindow", "width=200,height=100");   // Opens a new window
    	  myWindow.document.write("<!DOCTYPE html><b2>List Of Available Docs<b2><p><a href='file://montefiore.org/cenTRALFILES/data/HIPAA/ETCS/IDHub/documents/ConfidentialityAgreement.pdf' type='application/octet-stream' download>Confidentiality Agreement</a></p><p><a href='file://montefiore.org/cenTRALFILES/data/HIPAA/ETCS/IDHub/documents/MMC_USER_SYSTEM_ACCESS_FORM.DOCX'>User acces Form</a></p>");   // Text in the new window
    	
        //mywindow.moveTo(0, 0);

    //	pdfObject = document.getElementById("pdfIFrame");
    }
    catch(e)
     {
    	alert("Error in loadIFrame \name:"+e.name+"\nmessage:"+e.message);
      }
}


function moveIFrame(x,y,w,h) {
    var frameRef=document.getElementById("pdfFrame");
    frameRef.style.left=x;
    frameRef.style.top=y;
    var iFrameRef=document.getElementById("pdfIFrame");    
    iFrameRef.width=w;
    iFrameRef.height=h;
}

function hideIFrame(){
    document.getElementById("pdfFrame").style.visibility="hidden";
}
    
function showIFrame(){
    document.getElementById("pdfFrame").style.visibility="visible";
}

/*
 * If you want to hide the PDF in your Flex interface and still print it, on click of a button,
 * This function will allow you to do that.
 */
function printIFramePDF(srcUrl)
	{
		try{
			//if (navigator.appName.indexOf ("Microsoft") !=-1) //For IE (7) 	
				{ 
				 	if(document.getElementById("pdfFrame").style.visibility == "visible")
				  		{pdfObject.print();}
				  		else
				  		{
				  		 showIFrame();
				  		 pdfObject.print();
				  		 setTimeout("hideIFrame()", 800);
				  		 }
				}
		//	else //for non-IE browser (FF)   
			 {
			 	//frames["pdfIFrame"].focus();
			//	frames["pdfIFrame"].print();
			  }
			   
			}
		catch(e){
			alert("Error in printIFramePDF:\n name = "+ e.name + "\n message = " + e.message);
		}
}
